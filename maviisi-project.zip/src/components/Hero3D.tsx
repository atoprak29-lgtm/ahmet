import { useEffect, useMemo, useRef, useState, Suspense } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { Float, Environment, ContactShadows, RoundedBox, Text } from "@react-three/drei";
import * as THREE from "three";

function AirStream({ offset, side }: { offset: number; side: 1 | -1 }) {
  const ref = useRef<THREE.Mesh>(null!);
  useFrame((state) => {
    if (!ref.current) return;
    const t = (state.clock.elapsedTime + offset) % 2;
    ref.current.position.y = -0.35 - t * 0.9;
    ref.current.position.x = side * (0.2 + t * 0.15);
    ref.current.position.z = 0.6 + Math.sin(t * 3) * 0.1;
    (ref.current.material as THREE.MeshBasicMaterial).opacity = Math.max(0, 0.7 - t * 0.4);
    const s = 0.15 + t * 0.25;
    ref.current.scale.set(s, s * 0.4, s);
  });
  return (
    <mesh ref={ref}>
      <sphereGeometry args={[1, 16, 16]} />
      <meshBasicMaterial color="#7dd3fc" transparent opacity={0.6} toneMapped={false} depthWrite={false} />
    </mesh>
  );
}

function ACUnit() {
  const group = useRef<THREE.Group>(null!);
  const louver = useRef<THREE.Mesh>(null!);
  const led = useRef<THREE.Mesh>(null!);

  useFrame((state) => {
    const t = state.clock.elapsedTime;
    if (group.current) {
      group.current.rotation.y = Math.sin(t * 0.35) * 0.6;
      group.current.rotation.x = Math.sin(t * 0.25) * 0.08;
    }
    if (louver.current) {
      louver.current.rotation.x = -0.3 + Math.sin(t * 1.5) * 0.3;
    }
    if (led.current) {
      (led.current.material as THREE.MeshStandardMaterial).emissiveIntensity =
        1.5 + Math.sin(t * 4) * 0.5;
    }
  });

  // vent slats
  const slats = useMemo(() => Array.from({ length: 14 }, (_, i) => i), []);

  return (
    <Float speed={1} rotationIntensity={0.15} floatIntensity={0.6}>
      <group ref={group}>
        {/* main body */}
        <RoundedBox args={[3.4, 1.05, 0.85]} radius={0.18} smoothness={8} castShadow receiveShadow>
          <meshStandardMaterial color="#f8fafc" metalness={0.35} roughness={0.25} />
        </RoundedBox>

        {/* top vent grille */}
        <group position={[0, 0.4, 0.05]}>
          {slats.map((i) => (
            <mesh key={i} position={[-1.5 + i * 0.23, 0, 0.38]}>
              <boxGeometry args={[0.18, 0.18, 0.04]} />
              <meshStandardMaterial color="#e2e8f0" metalness={0.4} roughness={0.5} />
            </mesh>
          ))}
        </group>

        {/* front face accent strip */}
        <mesh position={[0, 0.05, 0.43]}>
          <boxGeometry args={[3.2, 0.04, 0.02]} />
          <meshStandardMaterial color="#0ea5e9" emissive="#0ea5e9" emissiveIntensity={0.8} toneMapped={false} />
        </mesh>

        {/* LED indicator */}
        <mesh ref={led} position={[-1.45, -0.05, 0.435]}>
          <sphereGeometry args={[0.05, 16, 16]} />
          <meshStandardMaterial color="#22d3ee" emissive="#22d3ee" emissiveIntensity={2} toneMapped={false} />
        </mesh>

        {/* bottom louver (air direction blade) */}
        <mesh ref={louver} position={[0, -0.45, 0.35]}>
          <boxGeometry args={[3.2, 0.12, 0.45]} />
          <meshStandardMaterial color="#f1f5f9" metalness={0.3} roughness={0.4} />
        </mesh>

        {/* dark air outlet shadow */}
        <mesh position={[0, -0.5, 0.42]}>
          <boxGeometry args={[3.0, 0.02, 0.01]} />
          <meshBasicMaterial color="#020617" />
        </mesh>

        {/* Baymak brand text - front face, right side */}
        <Text
          position={[1.05, -0.05, 0.44]}
          fontSize={0.16}
          color="#0ea5e9"
          anchorX="center"
          anchorY="middle"
          letterSpacing={0.05}
          outlineWidth={0.004}
          outlineColor="#0369a1"
        >
          BAYMAK
        </Text>

        {/* cool air streams */}
        <AirStream offset={0} side={-1} />
        <AirStream offset={0.5} side={-1} />
        <AirStream offset={1.0} side={1} />
        <AirStream offset={1.5} side={1} />
        <AirStream offset={0.25} side={-1} />
        <AirStream offset={1.25} side={1} />
      </group>
    </Float>
  );
}

function Scene() {
  return (
    <>
      <ambientLight intensity={0.5} />
      <directionalLight position={[5, 6, 5]} intensity={1.4} castShadow />
      <pointLight position={[-4, 2, 3]} intensity={1.2} color="#7dd3fc" />
      <pointLight position={[4, -2, 3]} intensity={1} color="#e0f2fe" />
      <ACUnit />
      <ContactShadows position={[0, -1.6, 0]} opacity={0.45} scale={10} blur={2.8} far={4} />
      <Environment preset="city" />
    </>
  );
}

export default function Hero3D() {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  if (!mounted) {
    return <div className="w-full aspect-[4/3]" />;
  }

  return (
    <div className="relative w-full aspect-[4/3]">
      <Canvas
        camera={{ position: [0, 0.2, 5.2], fov: 42 }}
        dpr={[1, 2]}
        shadows
        gl={{ alpha: true, antialias: true }}
        style={{ background: "transparent" }}
      >
        <Suspense fallback={null}>
          <Scene />
        </Suspense>
      </Canvas>
    </div>
  );
}
