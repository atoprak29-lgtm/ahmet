import { Link } from "@tanstack/react-router";
import { Flame, Menu, Phone, MessageCircle, X } from "lucide-react";
import { useState } from "react";

const nav = [
  { to: "/", label: "Anasayfa" },
  { to: "/kombi", label: "Kombi" },
  { to: "/klima", label: "Klima" },
  { to: "/sofben", label: "Şofben" },
  
  { to: "/hizmetler", label: "Hizmetler" },
  { to: "/hakkimizda", label: "Hakkımızda" },
  { to: "/iletisim", label: "İletişim" },
] as const;

const TEL = "+905437786356";
const TEL_DISPLAY = "0543 778 63 56";
const WA = "https://wa.me/905437786356";

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/60 bg-background/85 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6">
        <Link to="/" className="flex items-center gap-2 font-bold text-lg">
          <span className="grid h-9 w-9 place-items-center rounded-lg" style={{ background: "var(--gradient-hero)" }}>
            <Flame className="h-5 w-5 text-primary-foreground" />
          </span>
          <span className="tracking-tight text-primary">Maviısı</span>
        </Link>
        <nav className="hidden lg:flex items-center gap-1">
          {nav.map((n) => (
            <Link
              key={n.to}
              to={n.to}
              className="rounded-md px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground hover:bg-secondary"
              activeProps={{ className: "text-primary bg-secondary" }}
              activeOptions={{ exact: n.to === "/" }}
            >
              {n.label}
            </Link>
          ))}
        </nav>
        <div className="flex items-center gap-2">
          <a href={WA} target="_blank" rel="noopener noreferrer" className="hidden md:inline-flex items-center gap-2 rounded-lg bg-green-600 px-3 py-2 text-sm font-semibold text-white shadow-md transition-transform hover:scale-[1.02]">
            <MessageCircle className="h-4 w-4" />
            WhatsApp
          </a>
          <a href={`tel:${TEL}`} className="hidden sm:inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground shadow-md transition-transform hover:scale-[1.02]">
            <Phone className="h-4 w-4" />
            {TEL_DISPLAY}
          </a>
          <button onClick={() => setOpen(!open)} className="lg:hidden grid h-10 w-10 place-items-center rounded-md border border-border" aria-label="Menü">
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>
      {open && (
        <nav className="lg:hidden border-t border-border bg-background">
          <div className="mx-auto flex max-w-7xl flex-col p-4 gap-1">
            {nav.map((n) => (
              <Link
                key={n.to}
                to={n.to}
                onClick={() => setOpen(false)}
                className="rounded-md px-4 py-3 text-base font-medium text-foreground hover:bg-secondary"
                activeProps={{ className: "text-primary bg-secondary" }}
                activeOptions={{ exact: n.to === "/" }}
              >
                {n.label}
              </Link>
            ))}
            <a href={WA} target="_blank" rel="noopener noreferrer" className="mt-2 inline-flex items-center justify-center gap-2 rounded-lg bg-green-600 px-4 py-3 text-base font-semibold text-white">
              <MessageCircle className="h-4 w-4" /> WhatsApp'tan Yaz
            </a>
            <a href={`tel:${TEL}`} className="mt-1 inline-flex items-center justify-center gap-2 rounded-lg bg-primary px-4 py-3 text-base font-semibold text-primary-foreground">
              <Phone className="h-4 w-4" /> Hemen Ara
            </a>
          </div>
        </nav>
      )}
    </header>
  );
}
