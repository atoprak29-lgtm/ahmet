import type { ReactNode } from "react";

interface PageHeroProps {
  eyebrow?: string;
  title: string;
  description: ReactNode;
}

export function PageHero({ eyebrow, title, description }: PageHeroProps) {
  return (
    <section className="relative border-b border-border overflow-hidden">
      <div className="absolute inset-0 -z-10 opacity-[0.06]" style={{ background: "var(--gradient-hero)" }} />
      <div className="mx-auto max-w-7xl px-4 sm:px-6 py-14 md:py-20">
        {eyebrow && <p className="text-sm font-semibold text-accent uppercase tracking-wider">{eyebrow}</p>}
        <h1 className="mt-2 text-4xl sm:text-5xl font-bold tracking-tight max-w-3xl">{title}</h1>
        <p className="mt-4 text-lg text-muted-foreground max-w-2xl">{description}</p>
      </div>
    </section>
  );
}
