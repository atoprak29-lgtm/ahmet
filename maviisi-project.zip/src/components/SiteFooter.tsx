import { Link } from "@tanstack/react-router";
import { Flame, Mail, MapPin, Phone } from "lucide-react";

const TEL = "0543 778 63 56";
const TEL_HREF = "+905437786356";
const EMAIL = "info@isitek.com.tr";
const ADRES = "Bağlar Mah. Kayapınar Cad. No:12, Diyarbakır";

export function SiteFooter() {
  return (
    <footer className="mt-24 border-t border-border bg-secondary/40">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 py-12 grid gap-10 md:grid-cols-4">
        <div>
          <div className="flex items-center gap-2 font-bold text-lg">
            <span className="grid h-9 w-9 place-items-center rounded-lg" style={{ background: "var(--gradient-hero)" }}>
              <Flame className="h-5 w-5 text-primary-foreground" />
            </span>
            <span className="text-primary">Maviısı</span>
          </div>
          <p className="mt-3 text-sm text-muted-foreground">
            Diyarbakır ve çevre illerde kombi ve klima satış, montaj ve servis hizmetleri. 7/24 yetkili teknik destek.
          </p>
        </div>
        <div>
          <h3 className="font-semibold text-sm mb-3">Hizmetler</h3>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li><Link to="/kombi" className="hover:text-primary">Kombi Montajı</Link></li>
            <li><Link to="/klima" className="hover:text-primary">Klima Montajı</Link></li>
            <li><Link to="/sofben" className="hover:text-primary">Şofben Servisi</Link></li>
            
            <li><Link to="/hizmetler" className="hover:text-primary">Bakım & Onarım</Link></li>
            <li><Link to="/hizmetler" className="hover:text-primary">Petek Temizliği</Link></li>
          </ul>
        </div>
        <div>
          <h3 className="font-semibold text-sm mb-3">Kurumsal</h3>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li><Link to="/hakkimizda" className="hover:text-primary">Hakkımızda</Link></li>
            <li><Link to="/iletisim" className="hover:text-primary">İletişim</Link></li>
          </ul>
        </div>
        <div>
          <h3 className="font-semibold text-sm mb-3">İletişim</h3>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li className="flex items-start gap-2"><Phone className="h-4 w-4 mt-0.5 text-primary" /> <a href={`tel:${TEL_HREF}`} className="hover:text-primary">{TEL}</a></li>
            <li className="flex items-start gap-2"><Mail className="h-4 w-4 mt-0.5 text-primary" /> <a href={`mailto:${EMAIL}`} className="hover:text-primary">{EMAIL}</a></li>
            <li className="flex items-start gap-2"><MapPin className="h-4 w-4 mt-0.5 text-primary" /> {ADRES}</li>
          </ul>
        </div>
      </div>
      <div className="border-t border-border">
        <p className="mx-auto max-w-7xl px-4 sm:px-6 py-5 text-xs text-muted-foreground text-center">
          © {new Date().getFullYear()} <span className="text-primary font-semibold">Maviısı</span> Isıtma & Soğutma Sistemleri. Tüm hakları saklıdır.
        </p>
      </div>
    </footer>
  );
}
