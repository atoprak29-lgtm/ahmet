import { createFileRoute } from "@tanstack/react-router";
import { PageHero } from "@/components/PageHero";
import { Award, Heart, Target } from "lucide-react";

export const Route = createFileRoute("/hakkimizda")({
  head: () => ({
    meta: [
      { title: "Hakkımızda | Diyarbakır Kombi & Klima | Maviısı" },
      { name: "description", content: "Maviısı olarak 15+ yıllık deneyimimizle Diyarbakır ve çevre illerde kombi ve klima sektöründe binlerce müşterimize güvenilir hizmet sunuyoruz." },
      { property: "og:title", content: "Hakkımızda | Maviısı" },
      { property: "og:description", content: "Diyarbakır'da 15+ yıllık deneyim, 10.000+ mutlu müşteri." },
      { property: "og:url", content: "/hakkimizda" },
    ],
    links: [{ rel: "canonical", href: "/hakkimizda" }],
  }),
  component: Hakkimizda,
});

function Hakkimizda() {
  return (
    <>
      <PageHero
        eyebrow="Hakkımızda"
        title="15+ Yıllık Tecrübe, Binlerce Mutlu Müşteri"
        description={<><span className="text-primary font-semibold">Maviısı</span>; Diyarbakır ve çevre illerde kombi ve klima satış, montaj ve servis alanında uzmanlaşmış bir mühendislik firmasıdır.</>}
      />
      <section className="mx-auto max-w-7xl px-4 sm:px-6 py-16 grid lg:grid-cols-3 gap-8">
        {[
          { i: Target, t: "Misyonumuz", d: "Diyarbakır ve çevre illerde müşterilerimize en uygun ısıtma ve soğutma çözümlerini, kaliteli işçilik ve adil fiyatla sunmak." },
          { i: Heart, t: "Vizyonumuz", d: "Güneydoğu Anadolu'nun en güvenilir kombi ve klima servis markası olmak." },
          { i: Award, t: "Değerlerimiz", d: "Dürüstlük, şeffaflık, müşteri memnuniyeti ve teknik mükemmellik." },
        ].map((c) => (
          <div key={c.t} className="rounded-2xl border border-border bg-card p-8">
            <span className="grid h-12 w-12 place-items-center rounded-xl bg-primary/10 text-primary"><c.i className="h-6 w-6" /></span>
            <h2 className="mt-4 text-xl font-bold">{c.t}</h2>
            <p className="mt-3 text-muted-foreground">{c.d}</p>
          </div>
        ))}
      </section>
      <section className="bg-secondary/40 border-y border-border">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 py-16 prose prose-slate">
          <h2 className="text-3xl font-bold">Neden <span className="text-primary">Maviısı</span>?</h2>
          <p className="mt-4 text-muted-foreground">2009 yılından bu yana Diyarbakır ve çevre illerde (Mardin, Batman, Şanlıurfa, Adıyaman, Elazığ, Malatya) binlerce konut ve iş yerinde kombi ve klima montajı, bakımı ve onarımı gerçekleştirdik. Sertifikalı teknik ekibimiz; Vaillant, Bosch, Demirdöküm, Baymak, Mitsubishi, Daikin gibi pek çok markada yetkili servis hizmeti vermektedir.</p>
          <p className="mt-4 text-muted-foreground">İşimizin merkezinde müşteri memnuniyeti var. Şeffaf fiyatlandırma, garantili işçilik ve hızlı çözüm anlayışımızla farkımızı ortaya koyuyoruz.</p>
        </div>
      </section>
    </>
  );
}
