import { createFileRoute } from "@tanstack/react-router";
import { PageHero } from "@/components/PageHero";
import { Clock, Mail, MapPin, Phone, MessageCircle } from "lucide-react";
import { useState } from "react";

const TEL = "+905437786356";
const TEL_DISPLAY = "0543 778 63 56";
const WA = "https://wa.me/905437786356";
const EMAIL = "info@isitek.com.tr";
const ADRES = "Bağlar Mah. Kayapınar Cad. No:12, Diyarbakır";

export const Route = createFileRoute("/iletisim")({
  head: () => ({
    meta: [
      { title: "İletişim | Diyarbakır Kombi & Klima Servisi | Maviısı" },
      { name: "description", content: "Diyarbakır ve çevre illerde kombi ve klima ihtiyaçlarınız için bize ulaşın. Telefon, WhatsApp, e-posta ve formla 7/24 destek." },
      { property: "og:title", content: "İletişim | Maviısı" },
      { property: "og:description", content: "Bize ulaşın, ücretsiz keşif ve fiyat teklifi alın." },
      { property: "og:url", content: "/iletisim" },
    ],
    links: [{ rel: "canonical", href: "/iletisim" }],
  }),
  component: Iletisim,
});

function Iletisim() {
  const [sent, setSent] = useState(false);
  return (
    <>
      <PageHero
        eyebrow="İletişim"
        title="Bize Ulaşın"
        description="Diyarbakır ve çevre illerde kombi ve klima ihtiyaçlarınız için uzman ekibimiz dakikalar içinde size dönüş yapar."
      />
      <section className="mx-auto max-w-7xl px-4 sm:px-6 py-16 grid lg:grid-cols-2 gap-12">
        <div className="space-y-5">
          {[
            { i: Phone, t: "Telefon", d: TEL_DISPLAY, href: `tel:${TEL}` },
            { i: MessageCircle, t: "WhatsApp", d: "Hemen Mesaj Gönder", href: WA },
            { i: Mail, t: "E-posta", d: EMAIL, href: `mailto:${EMAIL}` },
            { i: MapPin, t: "Adres", d: ADRES },
            { i: Clock, t: "Çalışma Saatleri", d: "Hafta içi 08:00 – 20:00 · Acil: 7/24" },
          ].map((c) => {
            const Inner = (
              <>
                <span className="grid h-12 w-12 place-items-center rounded-xl bg-primary/10 text-primary">
                  <c.i className="h-5 w-5" />
                </span>
                <div>
                  <p className="font-semibold">{c.t}</p>
                  <p className="text-muted-foreground text-sm mt-0.5">{c.d}</p>
                </div>
              </>
            );
            return c.href ? (
              <a key={c.t} href={c.href} target={c.i === MessageCircle ? "_blank" : undefined} rel={c.i === MessageCircle ? "noopener noreferrer" : undefined} className="flex items-center gap-4 rounded-2xl border border-border bg-card p-5 hover:border-primary transition-colors">{Inner}</a>
            ) : (
              <div key={c.t} className="flex items-center gap-4 rounded-2xl border border-border bg-card p-5">{Inner}</div>
            );
          })}
        </div>
        <form
          onSubmit={(e) => { e.preventDefault(); setSent(true); }}
          className="rounded-2xl border border-border bg-card p-6 md:p-8 space-y-4"
          style={{ boxShadow: "var(--shadow-card)" }}
        >
          <h2 className="text-2xl font-bold">Ücretsiz Keşif Talebi</h2>
          <p className="text-sm text-muted-foreground">Formu doldurun, en kısa sürede sizi arayalım.</p>
          <div className="grid sm:grid-cols-2 gap-4">
            <Field label="Ad Soyad" name="name" required />
            <Field label="Telefon" name="phone" type="tel" required />
          </div>
          <Field label="E-posta" name="email" type="email" />
          <div>
            <label className="text-sm font-medium">Hizmet</label>
            <select required name="service" className="mt-1 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm">
              <option value="">Seçiniz</option>
              <option>Kombi Montajı</option>
              <option>Klima Montajı</option>
              <option>Şofben Servisi</option>
              
              <option>Bakım & Onarım</option>
              <option>Petek Temizliği</option>
              <option>Diğer</option>
            </select>
          </div>
          <div>
            <label className="text-sm font-medium">Şehir</label>
            <select required name="city" className="mt-1 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm">
              <option value="">Seçiniz</option>
              <option>Diyarbakır</option>
              <option>Mardin</option>
              <option>Batman</option>
              <option>Şanlıurfa</option>
              <option>Adıyaman</option>
              <option>Elazığ</option>
              <option>Malatya</option>
            </select>
          </div>
          <div>
            <label className="text-sm font-medium">Mesajınız</label>
            <textarea name="message" rows={4} className="mt-1 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm" />
          </div>
          <button type="submit" className="w-full rounded-xl bg-primary px-6 py-3 font-semibold text-primary-foreground hover:opacity-95">
            {sent ? "Talebiniz alındı ✓" : "Teklif İste"}
          </button>
        </form>
      </section>
    </>
  );
}

function Field({ label, name, type = "text", required }: { label: string; name: string; type?: string; required?: boolean }) {
  return (
    <div>
      <label className="text-sm font-medium">{label}{required && <span className="text-accent"> *</span>}</label>
      <input required={required} name={name} type={type} className="mt-1 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm" />
    </div>
  );
}
