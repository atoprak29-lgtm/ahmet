import { createFileRoute } from "@tanstack/react-router";
import { PageHero } from "@/components/PageHero";
import { CheckCircle2, Droplets, Phone, MessageCircle } from "lucide-react";
import sofbenImg from "@/assets/sofben.jpg";

const TEL = "+905437786356";
const WA = "https://wa.me/905437786356";

export const Route = createFileRoute("/sofben")({
  head: () => ({
    meta: [
      { title: "Diyarbakır Şofben Satış, Montaj ve Servis | Maviısı" },
      { name: "description", content: "Diyarbakır ve çevre illerde doğalgazlı ve elektrikli şofben satışı, montajı, bakımı ve arıza onarımı. Tüm markalar için yetkili servis ve uygun fiyat." },
      { property: "og:title", content: "Diyarbakır Şofben Satış, Montaj ve Servis | Maviısı" },
      { property: "og:description", content: "Diyarbakır'da şofben satışı, montajı ve yetkili servis hizmeti." },
      { property: "og:url", content: "/sofben" },
    ],
    links: [{ rel: "canonical", href: "/sofben" }],
    scripts: [{
      type: "application/ld+json",
      children: JSON.stringify({
        "@context": "https://schema.org",
        "@type": "Service",
        serviceType: "Şofben Satış ve Servis",
        provider: { "@type": "LocalBusiness", name: "Maviısı" },
        areaServed: "Diyarbakır, Mardin, Batman, Şanlıurfa, Adıyaman, Elazığ, Malatya",
      }),
    }],
  }),
  component: SofbenPage,
});

const services = [
  { t: "Şofben Satışı", d: "Doğalgazlı ve elektrikli şofbenlerde tüm markalar için uygun fiyat garantisi." },
  { t: "Şofben Montajı", d: "Standartlara uygun, güvenli ve hızlı şofben kurulumu." },
  { t: "Yıllık Bakım", d: "Verimli ve güvenli kullanım için periyodik bakım hizmeti." },
  { t: "Arıza Onarımı", d: "Tüm şofben markalarında orijinal yedek parça ile arıza tespiti ve tamir." },
  { t: "Baca & Sızıntı Kontrolü", d: "Gaz kaçağı ve baca güvenliği kontrolleri ile risk yönetimi." },
  { t: "Yedek Parça", d: "Orijinal yedek parça temini ve uygulaması." },
];

function SofbenPage() {
  return (
    <>
      <PageHero
        eyebrow="Şofben Hizmetleri"
        title="Diyarbakır Şofben Satış, Montaj ve Yetkili Servis"
        description="Diyarbakır ve çevre illerde doğalgazlı ve elektrikli şofben ihtiyaçlarınız için uzman ekibimizle satış, montaj ve servis hizmeti."
      />
      <section className="mx-auto max-w-7xl px-4 sm:px-6 py-16 grid lg:grid-cols-2 gap-12 items-center">
        <img src={sofbenImg} alt="Duvar tipi şofben cihazı" width={1024} height={1024} loading="lazy" className="rounded-2xl object-cover w-full aspect-square shadow-xl" />
        <div>
          <h2 className="text-3xl font-bold">Güvenli Sıcak Su, Doğru Şofben</h2>
          <p className="mt-4 text-muted-foreground">Şofben seçimi; kullanım sıklığı, su debisi ve yakıt tipine göre değişir. <span className="text-primary font-semibold">Maviısı</span> olarak Diyarbakır'da ücretsiz keşif ile size en uygun cihazı öneriyor, montajını standartlara uygun şekilde gerçekleştiriyoruz.</p>
          <ul className="mt-6 space-y-3">
            {["Tüm markalarda satış & servis", "Güvenli ve standartlara uygun montaj", "Aynı gün servis imkânı", "Orijinal yedek parça"].map((i) => (
              <li key={i} className="flex items-start gap-3"><CheckCircle2 className="h-5 w-5 text-primary mt-0.5" /> <span>{i}</span></li>
            ))}
          </ul>
          <div className="mt-8 flex flex-wrap gap-3">
            <a href={`tel:${TEL}`} className="inline-flex items-center gap-2 rounded-xl bg-primary px-6 py-3 font-semibold text-primary-foreground">
              <Phone className="h-4 w-4" /> Hemen Teklif Al
            </a>
            <a href={WA} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 rounded-xl bg-green-600 px-6 py-3 font-semibold text-white">
              <MessageCircle className="h-4 w-4" /> WhatsApp
            </a>
          </div>
        </div>
      </section>
      <section className="bg-secondary/40 border-y border-border">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 py-16">
          <h2 className="text-3xl font-bold text-center">Şofben Hizmetlerimiz</h2>
          <div className="mt-10 grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {services.map((s) => (
              <div key={s.t} className="rounded-2xl bg-card p-6 border border-border">
                <span className="grid h-11 w-11 place-items-center rounded-lg bg-primary/10 text-primary"><Droplets className="h-5 w-5" /></span>
                <h3 className="mt-4 font-bold">{s.t}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{s.d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
