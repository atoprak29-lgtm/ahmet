import { createFileRoute } from "@tanstack/react-router";
import { PageHero } from "@/components/PageHero";
import { Wrench, Flame, Snowflake, Droplets, Wind, Activity, Droplet } from "lucide-react";

export const Route = createFileRoute("/hizmetler")({
  head: () => ({
    meta: [
      { title: "Hizmetlerimiz | Diyarbakır Kombi & Klima Servisi | Maviısı" },
      { name: "description", content: "Diyarbakır ve çevre illerde kombi montajı, klima montajı, petek temizliği, bakım, onarım ve gaz dolumu gibi tüm ısıtma ve soğutma hizmetlerimiz." },
      { property: "og:title", content: "Hizmetlerimiz | Maviısı" },
      { property: "og:description", content: "Diyarbakır'da ısıtma ve soğutma sistemlerinde tam kapsamlı servis." },
      { property: "og:url", content: "/hizmetler" },
    ],
    links: [{ rel: "canonical", href: "/hizmetler" }],
  }),
  component: Hizmetler,
});

const list = [
  { i: Flame, t: "Kombi Montajı", d: "Tüm marka kombilerin yetkili servis standartlarında montajı." },
  { i: Snowflake, t: "Klima Montajı", d: "Split, multi ve VRF klimalarda profesyonel kurulum." },
  { i: Droplet, t: "Şofben Servisi", d: "Doğalgazlı ve elektrikli şofbenlerde satış, montaj ve bakım." },
  
  { i: Droplets, t: "Petek Temizliği", d: "Kapalı devre pompalı sistemle petek ve tesisat temizliği." },
  { i: Wrench, t: "Bakım & Onarım", d: "Periyodik bakım ve arıza tespiti hizmetleri." },
  { i: Wind, t: "Gaz Dolumu", d: "Klimalarda R32 / R410A gaz dolumu ve kaçak tespiti." },
  { i: Activity, t: "Baca Gazı Ölçümü", d: "Yasal zorunluluk emisyon ölçüm raporu." },
];

function Hizmetler() {
  return (
    <>
      <PageHero
        eyebrow="Hizmetlerimiz"
        title="Isıtma ve Soğutmada Tam Kapsamlı Çözüm"
        description="Diyarbakır ve çevre illerde konutlardan iş yerlerine kadar her ölçekte projede ihtiyacınız olan tüm hizmetleri tek elden sunuyoruz."
      />
      <section className="mx-auto max-w-7xl px-4 sm:px-6 py-16">
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {list.map((s) => (
            <div key={s.t} className="rounded-2xl border border-border bg-card p-6 hover:shadow-xl transition-shadow" style={{ boxShadow: "var(--shadow-card)" }}>
              <span className="grid h-12 w-12 place-items-center rounded-xl bg-primary/10 text-primary">
                <s.i className="h-6 w-6" />
              </span>
              <h2 className="mt-4 text-xl font-bold">{s.t}</h2>
              <p className="mt-2 text-sm text-muted-foreground">{s.d}</p>
            </div>
          ))}
        </div>
      </section>
    </>
  );
}
