import { createFileRoute } from "@tanstack/react-router";
import { PageHero } from "@/components/PageHero";
import { CheckCircle2, Phone, MessageCircle, Snowflake } from "lucide-react";
import klimaImg from "@/assets/klima.jpg";

const TEL = "+905437786356";
const WA = "https://wa.me/905437786356";

export const Route = createFileRoute("/klima")({
  head: () => ({
    meta: [
      { title: "Diyarbakır Klima Satış, Montaj ve Servis | Maviısı" },
      { name: "description", content: "Diyarbakır ve çevre illerde klima satışı, profesyonel montaj, bakım, gaz dolumu ve arıza onarımı. Split, multi, VRF klimalarda yetkili servis." },
      { property: "og:title", content: "Diyarbakır Klima Satış, Montaj ve Servis | Maviısı" },
      { property: "og:description", content: "Diyarbakır'da tüm marka klimalar için satış, hızlı montaj ve bakım hizmetleri." },
      { property: "og:url", content: "/klima" },
    ],
    links: [{ rel: "canonical", href: "/klima" }],
    scripts: [{
      type: "application/ld+json",
      children: JSON.stringify({
        "@context": "https://schema.org",
        "@type": "Service",
        serviceType: "Klima Satış ve Servis",
        provider: { "@type": "LocalBusiness", name: "Maviısı" },
        areaServed: "Diyarbakır, Mardin, Batman, Şanlıurfa, Adıyaman, Elazığ, Malatya",
      }),
    }],
  }),
  component: KlimaPage,
});

const services = [
  { t: "Klima Satışı", d: "Mitsubishi, Daikin, Arçelik, Vestel, Samsung inverter klimalar." },
  { t: "Profesyonel Montaj", d: "Bakır boru, vakum testi ve doğru gaz şarjı ile standartlara uygun montaj." },
  { t: "Yıllık Bakım", d: "Filtre temizliği, drenaj kontrolü ve performans testi." },
  { t: "Gaz Dolumu", d: "R32 ve R410A gaz dolumu, kaçak tespiti ve onarımı." },
  { t: "Multi & VRF Sistemler", d: "İş yerleri için merkezi soğutma sistemleri kurulumu." },
  { t: "Demontaj & Taşıma", d: "Klimanızın güvenli sökümü, taşınması ve yeniden montajı." },
];

function KlimaPage() {
  return (
    <>
      <PageHero
        eyebrow="Klima Hizmetleri"
        title="Diyarbakır Klima Satış, Montaj ve Bakım"
        description="Diyarbakır ve çevre illerde yazın serinlik, kışın konfor için doğru klimayı doğru montajla teslim ediyoruz. Tüm markalar için yetkili servis."
      />
      <section className="mx-auto max-w-7xl px-4 sm:px-6 py-16 grid lg:grid-cols-2 gap-12 items-center">
        <div className="order-2 lg:order-1">
          <h2 className="text-3xl font-bold">Sessiz, Verimli ve Tasarruflu</h2>
          <p className="mt-4 text-muted-foreground">A++ enerji sınıfı inverter klimalar ile düşük fatura, yüksek konfor. Doğru kapasite seçimi ve hatasız montaj klimanızın ömrünü uzatır.</p>
          <ul className="mt-6 space-y-3">
            {["Ücretsiz keşif ve teklif", "Vakum testli profesyonel montaj", "1 yıl montaj garantisi", "Tüm markalarda yetkili servis"].map((i) => (
              <li key={i} className="flex items-start gap-3"><CheckCircle2 className="h-5 w-5 text-primary mt-0.5" /> <span>{i}</span></li>
            ))}
          </ul>
          <div className="mt-8 flex flex-wrap gap-3">
            <a href={`tel:${TEL}`} className="inline-flex items-center gap-2 rounded-xl bg-primary px-6 py-3 font-semibold text-primary-foreground">
              <Phone className="h-4 w-4" /> Ücretsiz Keşif
            </a>
            <a href={WA} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 rounded-xl bg-green-600 px-6 py-3 font-semibold text-white">
              <MessageCircle className="h-4 w-4" /> WhatsApp
            </a>
          </div>
        </div>
        <img src={klimaImg} alt="Duvar tipi split klima" width={1024} height={1024} loading="lazy" className="order-1 lg:order-2 rounded-2xl object-cover w-full aspect-square shadow-xl" />
      </section>
      <section className="bg-secondary/40 border-y border-border">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 py-16">
          <h2 className="text-3xl font-bold text-center">Klima Hizmetlerimiz</h2>
          <div className="mt-10 grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {services.map((s) => (
              <div key={s.t} className="rounded-2xl bg-card p-6 border border-border">
                <span className="grid h-11 w-11 place-items-center rounded-lg bg-primary/10 text-primary"><Snowflake className="h-5 w-5" /></span>
                <h3 className="mt-4 font-bold">{s.t}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{s.d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
