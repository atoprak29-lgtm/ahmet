import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";

import appCss from "../styles.css?url";
import { SiteHeader } from "../components/SiteHeader";
import { SiteFooter } from "../components/SiteFooter";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">Page not found</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Go home
          </Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold tracking-tight text-foreground">
          This page didn't load
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Something went wrong on our end. You can try refreshing or head back home.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button
            onClick={() => {
              router.invalidate();
              reset();
            }}
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Try again
          </button>
          <a
            href="/"
            className="inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent"
          >
            Go home
          </a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "Maviısı | Kombi ve Klima Satış, Montaj ve Servis Hizmetleri" },
      { name: "description", content: "Diyarbakır ve çevre illerde kombi ve klima satış, montaj, bakım ve onarım hizmetleri. Yetkili servis, uygun fiyat ve 7/24 teknik destek." },
      { name: "keywords", content: "diyarbakır kombi servisi, diyarbakır klima servisi, diyarbakır şofben servisi, diyarbakır kombi montajı, diyarbakır klima montajı, diyarbakır şofben montajı, diyarbakır petek temizliği, mardin kombi, batman klima, şanlıurfa kombi, adıyaman klima, elazığ kombi, malatya klima" },
      { property: "og:site_name", content: "Maviısı" },
      { property: "og:type", content: "website" },
      { property: "og:title", content: "Maviısı | Kombi ve Klima Satış, Montaj ve Servis Hizmetleri" },
      { property: "og:description", content: "Diyarbakır ve çevre illerde kombi ve klima satış, montaj, bakım ve onarım hizmetleri. Yetkili servis, uygun fiyat ve 7/24 teknik destek." },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: "Maviısı | Kombi ve Klima Satış, Montaj ve Servis Hizmetleri" },
      { name: "twitter:description", content: "Diyarbakır ve çevre illerde kombi ve klima satış, montaj, bakım ve onarım hizmetleri. Yetkili servis, uygun fiyat ve 7/24 teknik destek." },
      { property: "og:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/381112ae-dfa4-4cbc-b43b-a5e392da9bae/id-preview-3a3355a4--26433a55-18c4-4ec7-8ffb-018d63458712.lovable.app-1779132914511.png" },
      { name: "twitter:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/381112ae-dfa4-4cbc-b43b-a5e392da9bae/id-preview-3a3355a4--26433a55-18c4-4ec7-8ffb-018d63458712.lovable.app-1779132914511.png" },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      { rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Plus+Jakarta+Sans:wght@600;700;800&display=swap" },
    ],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "LocalBusiness",
          name: "Maviısı Isıtma & Soğutma",
          description: "Kombi ve klima satış, montaj ve servis hizmetleri",
      telephone: "+90 543 778 63 56",
      url: "https://wa.me/905437786356",
      address: { "@type": "PostalAddress", addressLocality: "Diyarbakır", addressCountry: "TR" },
      areaServed: "Diyarbakır, Mardin, Batman, Şanlıurfa, Adıyaman, Elazığ, Malatya",
        }),
      },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();

  return (
    <QueryClientProvider client={queryClient}>
      <div className="flex min-h-screen flex-col">
        <SiteHeader />
        <main className="flex-1">
          <Outlet />
        </main>
        <SiteFooter />
      </div>
    </QueryClientProvider>
  );
}
