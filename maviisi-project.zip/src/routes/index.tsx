import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, CheckCircle2, Clock, Shield, ThermometerSun, Wrench, Award, Phone, MessageCircle, Droplet } from "lucide-react";
import { lazy, Suspense } from "react";
import kombiImg from "@/assets/kombi.jpg";
import klimaImg from "@/assets/klima.jpg";
import sofbenImg from "@/assets/sofben.jpg";

const Hero3D = lazy(() => import("@/components/Hero3D"));

const TEL = "+905437786356";
const TEL_DISPLAY = "0543 778 63 56";
const WA = "https://wa.me/905437786356";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Diyarbakır Kombi ve Klima Satış, Montaj ve Servis | Maviısı" },
      { name: "description", content: "Diyarbakır ve çevre illerde kombi ve klima satışı, profesyonel montaj, bakım ve onarım. Yetkili servis, uygun fiyat garantisi ve 7/24 teknik destek." },
      { property: "og:title", content: "Diyarbakır Kombi ve Klima Satış, Montaj ve Servis | Maviısı" },
      { property: "og:description", content: "Diyarbakır'da yetkili kombi ve klima servisi, hızlı montaj ve uygun fiyat garantisi." },
      { property: "og:url", content: "/" },
    ],
    links: [{ rel: "canonical", href: "/" }],
  }),
  component: Index,
});

function Index() {
  return (
    <>
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 -z-10 opacity-[0.07]" style={{ background: "var(--gradient-hero)" }} />
        <div className="mx-auto max-w-7xl px-4 sm:px-6 py-16 md:py-24 grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <span className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-3 py-1 text-xs font-medium text-muted-foreground">
              <span className="h-2 w-2 rounded-full bg-accent animate-pulse" />
              Yetkili Servis · 7/24 Destek
            </span>
            <h1 className="mt-5 text-4xl sm:text-5xl lg:text-6xl font-bold leading-[1.1] tracking-tight">
              Diyarbakır'da Kombi ve Klima'da{" "}
              <span className="bg-clip-text text-transparent" style={{ backgroundImage: "var(--gradient-hero)" }}>
                Güvenilir Çözüm
              </span>
            </h1>
            <p className="mt-5 text-lg text-muted-foreground max-w-xl">
              <span className="text-primary font-semibold">Maviısı</span> olarak Diyarbakır ve çevre illerde kombi ve klima satışı, profesyonel montaj, bakım ve onarım hizmetlerini uygun fiyat garantisiyle sunuyoruz. Tüm markalar için yetkili servis.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <a href={`tel:${TEL}`} className="inline-flex items-center gap-2 rounded-xl bg-primary px-6 py-3 text-base font-semibold text-primary-foreground shadow-lg transition-transform hover:scale-[1.02]" style={{ boxShadow: "var(--shadow-elegant)" }}>
                <Phone className="h-5 w-5" /> Ücretsiz Keşif
              </a>
              <a href={WA} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 rounded-xl bg-green-600 px-6 py-3 text-base font-semibold text-white shadow-lg transition-transform hover:scale-[1.02]">
                <MessageCircle className="h-5 w-5" /> WhatsApp
              </a>
              <Link to="/hizmetler" className="inline-flex items-center gap-2 rounded-xl border border-border bg-card px-6 py-3 text-base font-semibold hover:bg-secondary">
                Hizmetlerimiz <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
            <dl className="mt-10 grid grid-cols-3 gap-6 max-w-md">
              {[
                { k: "15+", v: "Yıl Tecrübe" },
                { k: "10K+", v: "Mutlu Müşteri" },
                { k: "7/24", v: "Servis" },
              ].map((s) => (
                <div key={s.v}>
                  <dt className="text-2xl sm:text-3xl font-bold text-primary">{s.k}</dt>
                  <dd className="text-xs text-muted-foreground mt-1">{s.v}</dd>
                </div>
              ))}
            </dl>
          </div>
          <div className="relative">
            <div className="absolute -inset-4 rounded-3xl opacity-40 blur-3xl" style={{ background: "var(--gradient-hero)" }} />
            <Suspense fallback={<div className="relative w-full aspect-[4/3] rounded-2xl bg-gradient-to-br from-primary/20 to-accent/20" />}>
              <Hero3D />
            </Suspense>
          </div>
        </div>
      </section>

      {/* Services */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 py-16 md:py-24">
        <div className="text-center max-w-2xl mx-auto">
          <p className="text-sm font-semibold text-accent uppercase tracking-wider">Hizmetlerimiz</p>
          <h2 className="mt-3 text-3xl sm:text-4xl font-bold">Isıtma ve Soğutmada Tek Adres</h2>
          <p className="mt-4 text-muted-foreground">Diyarbakır ve çevre illerde konutlardan iş yerlerine kadar her ölçekte projede güvenilir hizmet.</p>
        </div>
        <div className="mt-12 grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          <Link to="/kombi" className="group relative overflow-hidden rounded-2xl border border-border bg-card hover:shadow-2xl transition-shadow" style={{ boxShadow: "var(--shadow-card)" }}>
            <img src={kombiImg} alt="Kombi cihazı" width={1024} height={1024} loading="lazy" className="w-full aspect-[16/10] object-cover transition-transform group-hover:scale-105" />
            <div className="p-6">
              <div className="flex items-center gap-3">
                <Flame2 />
                <h3 className="text-xl font-bold">Kombi Hizmetleri</h3>
              </div>
              <p className="mt-2 text-muted-foreground text-sm">Satış, montaj, bakım, petek temizliği ve arıza onarımı. Tüm markalar için yetkili servis.</p>
              <span className="mt-4 inline-flex items-center gap-1 text-primary font-semibold text-sm">Detaylar <ArrowRight className="h-4 w-4" /></span>
            </div>
          </Link>
          <Link to="/klima" className="group relative overflow-hidden rounded-2xl border border-border bg-card hover:shadow-2xl transition-shadow" style={{ boxShadow: "var(--shadow-card)" }}>
            <img src={klimaImg} alt="Duvar tipi klima" width={1024} height={1024} loading="lazy" className="w-full aspect-[16/10] object-cover transition-transform group-hover:scale-105" />
            <div className="p-6">
              <div className="flex items-center gap-3">
                <span className="grid h-10 w-10 place-items-center rounded-lg bg-primary/10 text-primary"><ThermometerSun className="h-5 w-5" /></span>
                <h3 className="text-xl font-bold">Klima Hizmetleri</h3>
              </div>
              <p className="mt-2 text-muted-foreground text-sm">Split, multi, VRF ve inverter klimalarda satış, montaj, bakım ve gaz dolumu.</p>
              <span className="mt-4 inline-flex items-center gap-1 text-primary font-semibold text-sm">Detaylar <ArrowRight className="h-4 w-4" /></span>
            </div>
          </Link>
          <Link to="/sofben" className="group relative overflow-hidden rounded-2xl border border-border bg-card hover:shadow-2xl transition-shadow" style={{ boxShadow: "var(--shadow-card)" }}>
            <img src={sofbenImg} alt="Şofben cihazı" width={1024} height={1024} loading="lazy" className="w-full aspect-[16/10] object-cover transition-transform group-hover:scale-105" />
            <div className="p-6">
              <div className="flex items-center gap-3">
                <span className="grid h-10 w-10 place-items-center rounded-lg bg-primary/10 text-primary"><Droplet className="h-5 w-5" /></span>
                <h3 className="text-xl font-bold">Şofben Hizmetleri</h3>
              </div>
              <p className="mt-2 text-muted-foreground text-sm">Doğalgazlı ve elektrikli şofbenlerde satış, montaj, bakım ve arıza onarımı.</p>
              <span className="mt-4 inline-flex items-center gap-1 text-primary font-semibold text-sm">Detaylar <ArrowRight className="h-4 w-4" /></span>
            </div>
          </Link>
        </div>
      </section>

      {/* Why us */}
      <section className="bg-secondary/40 border-y border-border">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 py-16 md:py-20">
          <div className="text-center max-w-2xl mx-auto">
            <h2 className="text-3xl sm:text-4xl font-bold">Neden <span className="text-primary">Maviısı</span>?</h2>
            <p className="mt-3 text-muted-foreground">Diyarbakır ve çevre illerde kombi ve klima montajında uzman ekip, garantili işçilik.</p>
          </div>
          <div className="mt-12 grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { i: Shield, t: "Garantili İşçilik", d: "Tüm montaj ve onarımlarda 2 yıl işçilik garantisi." },
              { i: Clock, t: "Hızlı Servis", d: "Aynı gün keşif, 24 saat içinde montaj imkânı." },
              { i: Award, t: "Yetkili Servis", d: "Vaillant, Bosch, Demirdöküm, Mitsubishi yetkili servisi." },
              { i: Wrench, t: "Uzman Ekip", d: "Sertifikalı, 10+ yıl deneyimli teknik personel." },
            ].map((f) => (
              <div key={f.t} className="rounded-2xl bg-card p-6 border border-border">
                <span className="grid h-12 w-12 place-items-center rounded-xl bg-primary/10 text-primary">
                  <f.i className="h-6 w-6" />
                </span>
                <h3 className="mt-4 font-bold text-lg">{f.t}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{f.d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 py-16 md:py-24">
        <div className="relative overflow-hidden rounded-3xl p-10 md:p-14 text-center" style={{ background: "var(--gradient-hero)" }}>
          <h2 className="text-3xl sm:text-4xl font-bold text-primary-foreground">Ücretsiz Keşif ve Fiyat Teklifi</h2>
          <p className="mt-3 text-primary-foreground/90 max-w-xl mx-auto">Diyarbakır ve çevre illerde kombi ve klima ihtiyaçlarınız için uzman ekibimiz hemen yanınızda. Şimdi arayın, dakikalar içinde fiyat teklifi alın.</p>
          <div className="mt-7 flex flex-wrap gap-3 justify-center">
            <a href={`tel:${TEL}`} className="inline-flex items-center gap-2 rounded-xl bg-background px-6 py-3 font-semibold text-foreground hover:bg-secondary">
              <Phone className="h-5 w-5 text-primary" /> {TEL_DISPLAY}
            </a>
            <a href={WA} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 rounded-xl bg-green-500 px-6 py-3 font-semibold text-white hover:bg-green-400">
              <MessageCircle className="h-5 w-5" /> WhatsApp'tan Yaz
            </a>
            <Link to="/iletisim" className="inline-flex items-center gap-2 rounded-xl border border-primary-foreground/30 px-6 py-3 font-semibold text-primary-foreground hover:bg-primary-foreground/10">
              İletişime Geç
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}

function Flame2() {
  return (
    <span className="grid h-10 w-10 place-items-center rounded-lg bg-accent/15 text-accent">
      <CheckCircle2 className="h-5 w-5" />
    </span>
  );
}
