import { createFileRoute } from "@tanstack/react-router";
import { PageHero } from "@/components/PageHero";
import { CheckCircle2, Flame, Phone, MessageCircle } from "lucide-react";
import kombiImg from "@/assets/kombi.jpg";

const TEL = "+905437786356";
const WA = "https://wa.me/905437786356";

export const Route = createFileRoute("/kombi")({
  head: () => ({
    meta: [
      { title: "Diyarbakır Kombi Satış, Montaj ve Servis | Maviısı" },
      { name: "description", content: "Diyarbakır ve çevre illerde kombi satışı, montajı, bakımı ve onarımı. Vaillant, Bosch, Demirdöküm, Baymak yetkili servisi. Uygun fiyat, hızlı çözüm." },
      { property: "og:title", content: "Diyarbakır Kombi Satış, Montaj ve Servis | Maviısı" },
      { property: "og:description", content: "Diyarbakır'da tüm marka kombiler için profesyonel satış, montaj ve yetkili servis hizmeti." },
      { property: "og:url", content: "/kombi" },
    ],
    links: [{ rel: "canonical", href: "/kombi" }],
    scripts: [{
      type: "application/ld+json",
      children: JSON.stringify({
        "@context": "https://schema.org",
        "@type": "Service",
        serviceType: "Kombi Satış ve Servis",
        provider: { "@type": "LocalBusiness", name: "Maviısı" },
        areaServed: "Diyarbakır, Mardin, Batman, Şanlıurfa, Adıyaman, Elazığ, Malatya",
      }),
    }],
  }),
  component: KombiPage,
});

const services = [
  { t: "Kombi Satışı", d: "Vaillant, Bosch, Demirdöküm, Baymak, Buderus ve daha fazlası için uygun fiyat garantisi." },
  { t: "Kombi Montajı", d: "Sertifikalı teknik ekiple güvenli, hızlı ve standartlara uygun montaj." },
  { t: "Yıllık Bakım", d: "Verim kaybını önleyen periyodik bakım ve temizlik hizmeti." },
  { t: "Arıza Onarımı", d: "Tüm kombi markalarında orijinal yedek parça ile arıza tespiti ve tamir." },
  { t: "Petek Temizliği", d: "Pompa sistemiyle kapalı devre petek temizliği, daha sıcak ve düşük faturalı ısınma." },
  { t: "Baca Gazı Ölçümü", d: "Yasal zorunluluk olan baca gazı emisyon ölçüm raporu." },
];

function KombiPage() {
  return (
    <>
      <PageHero
        eyebrow="Kombi Hizmetleri"
        title="Diyarbakır Kombi Satış, Montaj ve Yetkili Servis"
        description="Diyarbakır ve çevre illerde konutunuz ve iş yeriniz için en uygun kombi çözümünü uzman ekibimizle birlikte belirleyin. Tüm marka kombiler için profesyonel hizmet."
      />
      <section className="mx-auto max-w-7xl px-4 sm:px-6 py-16 grid lg:grid-cols-2 gap-12 items-center">
        <img src={kombiImg} alt="Modern duvar tipi kombi cihazı" width={1024} height={1024} loading="lazy" className="rounded-2xl object-cover w-full aspect-square shadow-xl" />
        <div>
          <h2 className="text-3xl font-bold">Doğru Kombi, Doğru Montaj</h2>
          <p className="mt-4 text-muted-foreground">Kombi seçimi; konutun büyüklüğü, kat sayısı, sıcak su ihtiyacı ve yakıt tipine göre değişir. <span className="text-primary font-semibold">Maviısı</span> olarak Diyarbakır'da ücretsiz keşif ile size en uygun cihazı öneriyor, montajını yetkili servis standartlarında gerçekleştiriyoruz.</p>
          <ul className="mt-6 space-y-3">
            {["Tüm markalarda yetkili servis", "2 yıl montaj garantisi", "Aynı gün servis imkânı", "Orijinal yedek parça"].map((i) => (
              <li key={i} className="flex items-start gap-3"><CheckCircle2 className="h-5 w-5 text-primary mt-0.5" /> <span>{i}</span></li>
            ))}
          </ul>
          <div className="mt-8 flex flex-wrap gap-3">
            <a href={`tel:${TEL}`} className="inline-flex items-center gap-2 rounded-xl bg-primary px-6 py-3 font-semibold text-primary-foreground">
              <Phone className="h-4 w-4" /> Hemen Teklif Al
            </a>
            <a href={WA} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 rounded-xl bg-green-600 px-6 py-3 font-semibold text-white">
              <MessageCircle className="h-4 w-4" /> WhatsApp
            </a>
          </div>
        </div>
      </section>
      <section className="bg-secondary/40 border-y border-border">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 py-16">
          <h2 className="text-3xl font-bold text-center">Kombi Hizmetlerimiz</h2>
          <div className="mt-10 grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {services.map((s) => (
              <div key={s.t} className="rounded-2xl bg-card p-6 border border-border">
                <span className="grid h-11 w-11 place-items-center rounded-lg bg-primary/10 text-primary"><Flame className="h-5 w-5" /></span>
                <h3 className="mt-4 font-bold">{s.t}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{s.d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
